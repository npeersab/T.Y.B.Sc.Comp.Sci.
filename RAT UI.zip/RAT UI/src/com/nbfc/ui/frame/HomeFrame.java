package com.nbfc.ui.frame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;

import com.nbfc.ui.panel.AboutPanel;
import com.nbfc.ui.panel.BIReportsConfigurationPanel;
import com.nbfc.ui.panel.BulkTestCasesPanel;
import com.nbfc.ui.panel.DashBoardPanel;
import com.nbfc.ui.panel.DatabaseConfigutationPanel;
import com.nbfc.ui.panel.HeaderPanel;
import com.nbfc.ui.panel.SingleTestCasePanel;

public class HomeFrame extends JFrame {
	private static final long serialVersionUID = 1L;

	public HomeFrame() {
		setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.gridx = constraints.gridy = 0;
		constraints.anchor = GridBagConstraints.NORTHWEST;
		constraints.insets = new Insets(20, 20, 10, 20);
		constraints.fill = GridBagConstraints.BOTH;
		constraints.weightx = 1;
		constraints.weighty = 0.2;
		

		add (new HeaderPanel(), constraints);
		
		
		JTabbedPane mainTabbedPane = new JTabbedPane(JTabbedPane.TOP);
		mainTabbedPane.setBackground(Color.WHITE);

		AboutPanel aboutPanel = new AboutPanel();
		mainTabbedPane.add("About RAT", aboutPanel); 

		DatabaseConfigutationPanel databaseConfigutationPanel = new DatabaseConfigutationPanel();
		mainTabbedPane.addTab("DB Configuration", databaseConfigutationPanel);
		
		BIReportsConfigurationPanel biReportsConfigurationPanel = new BIReportsConfigurationPanel();
		mainTabbedPane.add("BI Reports Config", biReportsConfigurationPanel);
		
		SingleTestCasePanel singleTestCasePanel = new SingleTestCasePanel();
		mainTabbedPane.add("Single Test Case", singleTestCasePanel);
		
		BulkTestCasesPanel bulkTestCasesPanel = new BulkTestCasesPanel();
		mainTabbedPane.add("Bulk Test Cases", bulkTestCasesPanel);
		
		DashBoardPanel dashBoardPanel = new DashBoardPanel();
		mainTabbedPane.add("Dashboard", dashBoardPanel);

		constraints.gridy++;
		constraints.fill = GridBagConstraints.BOTH;
		constraints.weighty = 0.8;
		constraints.insets = new Insets(10, 20, 20, 20);
		add(mainTabbedPane, constraints);

		setTitle("RAT");
		setSize(900, 500);
		setMinimumSize(new Dimension(900, 500));
		setLocationRelativeTo(null);
		setBackground(Color.WHITE);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
}

