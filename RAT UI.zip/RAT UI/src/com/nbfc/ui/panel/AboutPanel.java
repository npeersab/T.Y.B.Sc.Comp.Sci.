package com.nbfc.ui.panel;

import java.awt.Color;

import javax.swing.JPanel;

public class AboutPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	
//	private JTextArea aboutTextArea;
	
	public AboutPanel() {
//		aboutTextArea = new JTextArea(20, 20);
		
//		add(aboutTextArea);
		setBackground(Color.WHITE);
	}
}
