package com.nbfc.ui.panel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class AvailableDatabasePanel extends JPanel {
	private static final long serialVersionUID = 1L;
	
	private JList<String> profileList;
	
	private JButton removeButton;

	public AvailableDatabasePanel() {
		setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.insets = new Insets(10, 10, 10, 10);
		constraints.anchor = GridBagConstraints.NORTHWEST;
		constraints.gridx = constraints.gridy = 0;
		constraints.weightx = constraints.weighty = 1;

		
		
		JLabel label = new JLabel("Available DB Profiles: ");
		add(label, constraints);
		
		
		profileList = new JList<>(new String[] {
				"Profile 1", "Profile 2", "Profile 3", "Profile 4", "Profile 5", "Profile 6", "Profile 7"
		});
		
		JScrollPane profileScrollPane = new JScrollPane(profileList);
		profileScrollPane.setPreferredSize(new Dimension(300, 130));
		
		constraints.gridy++;
		add(profileScrollPane, constraints);
		
		
		removeButton = new JButton("Remove DB");
		constraints.gridy++;
		add(removeButton, constraints);
		setBackground(Color.WHITE);
	}
}
