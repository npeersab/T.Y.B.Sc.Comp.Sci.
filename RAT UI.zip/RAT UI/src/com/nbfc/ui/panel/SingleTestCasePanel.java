package com.nbfc.ui.panel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class SingleTestCasePanel extends JPanel {
	private static final long serialVersionUID = 1L;
	
	private JComboBox<String> profileComboBox;
	private JTextArea queryTextArea;
	private JComboBox<String> reportComobox;
	private JButton executeButton;
	private JButton resetButton;

	public SingleTestCasePanel() {
		setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();
		
		constraints.gridx = constraints.gridy = 0;
		constraints.weighty = constraints.weighty = 1;
		constraints.anchor = GridBagConstraints.NORTHWEST;
		constraints.insets = new Insets(10, 10, 10, 10);
		
		JLabel label = new JLabel("Databse Profile: ");
		add(label, constraints);
		
		label = new JLabel("Source Query: ");
		constraints.gridy++;
		add(label, constraints);
		
		label = new JLabel("Select Report: ");
		constraints.gridy++;
		add(label, constraints);
		
		profileComboBox = new JComboBox<>();
		profileComboBox.setPreferredSize(new Dimension(220, 25));
		constraints.gridx++;
		constraints.gridy = 0;
		constraints.gridwidth = 2;
		add(profileComboBox, constraints);
		
		queryTextArea = new JTextArea(5, 20);
		JScrollPane scrollPane = new JScrollPane(queryTextArea);
		scrollPane.setSize(100, 150);
		constraints.gridy++;
		add(scrollPane, constraints);
		
		reportComobox = new JComboBox<>();
		reportComobox.setPreferredSize(new Dimension(220, 25));
		constraints.gridy++;
		add(reportComobox, constraints);
		
		executeButton = new JButton("Execute");
		constraints.gridy++;
		constraints.gridwidth = 1;
		add(executeButton, constraints);
		
		resetButton = new JButton("Reset");
		constraints.gridx++;
		add(resetButton, constraints);
		
		label = new JLabel("Result: ");
		constraints.gridy = 0;
		constraints.gridx++;
		add(label, constraints);
		
		setBackground(Color.WHITE);
	}
}
