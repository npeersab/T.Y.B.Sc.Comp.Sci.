package com.nbfc.ui.panel;

import java.awt.Color;

import javax.swing.JPanel;

public class DashBoardPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	
	public DashBoardPanel() {
		setBackground(Color.WHITE);
	}
}
