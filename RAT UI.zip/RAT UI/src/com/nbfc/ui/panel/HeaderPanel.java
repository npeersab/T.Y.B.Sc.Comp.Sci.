package com.nbfc.ui.panel;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.nbfc.ui.ImgSrc;

public class HeaderPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	public HeaderPanel() {
		setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.gridx = constraints.gridy = 0;
		constraints.insets = new Insets(20, 20, 20, 20);
		constraints.weightx = constraints.weighty = 1;
		
		add(new JLabel(new ImageIcon(ImgSrc.getCapgeminiLogo())), constraints);
		
		constraints.anchor = GridBagConstraints.CENTER;
		JLabel label = new JLabel("Report Automation Tool");
		label.setFont(new Font("Arial", Font.BOLD, 40));
		
		constraints.gridx = 1;
		add(label, constraints);
		
		constraints.gridx = 2;
		add(new JLabel(new ImageIcon(ImgSrc.getCapgeminiLogo())), constraints);
		setBackground(Color.WHITE);
	}
}
