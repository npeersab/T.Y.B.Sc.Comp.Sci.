package com.nbfc.ui.panel;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class AddDatabasePanel extends JPanel{
	private static final long serialVersionUID = 1L;
	private JTextField serverTextField;
	private JTextField dbSchemaTextField;
	private JTextField usernameTextField;
	private JPasswordField passwordField;
	
	private JButton addButton;
	private JButton resetButton; 
	
	public AddDatabasePanel() {
		setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.gridx = constraints.gridy = 0;
		constraints.anchor = GridBagConstraints.NORTHWEST;
		constraints.insets = new Insets(10, 10, 10, 10);
		constraints.weightx = constraints.weighty = 1;
		
		
		constraints.gridwidth = 2;
		add(new JLabel("Add Database Profile: "), constraints);
		
		
		constraints.gridwidth = 1;
		constraints.gridy++;
		add(new JLabel("Server: "), constraints);
		
		constraints.gridy++;
		add(new JLabel("DB Schema: "), constraints);
		
		constraints.gridy++;
		add(new JLabel("User Name: "), constraints);
		
		constraints.gridy++;
		add(new JLabel("Password: "), constraints);
		
		
		serverTextField = new JTextField(15);
		constraints.gridx++;
		constraints.gridy = 1;
		constraints.gridwidth = 2;
		add(serverTextField, constraints);
		
		
		dbSchemaTextField = new JTextField(15);
		constraints.gridy++;
		add(dbSchemaTextField, constraints);
		
		usernameTextField = new JTextField(15);
		constraints.gridy++;
		add(usernameTextField, constraints);
		
		passwordField = new JPasswordField(15);
		constraints.gridy++;
		add(passwordField, constraints);
		
		
		addButton = new JButton("Test & Add");
		constraints.gridwidth = 1;
		constraints.gridy++;
		add(addButton, constraints);
		
		resetButton = new JButton("Reset");
		constraints.gridx++;
		add(resetButton, constraints);
		setBackground(Color.WHITE);
	}
}
