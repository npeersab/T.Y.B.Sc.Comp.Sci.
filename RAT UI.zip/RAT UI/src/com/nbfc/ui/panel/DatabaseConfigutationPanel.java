package com.nbfc.ui.panel;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JPanel;

public class DatabaseConfigutationPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	public DatabaseConfigutationPanel() {
		setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.gridx = constraints.gridy = 0;
		constraints.anchor = GridBagConstraints.NORTHWEST;
		constraints.insets = new Insets(10, 10, 10, 10);
		constraints.fill = GridBagConstraints.BOTH;
		constraints.weightx = 1;
		constraints.weighty = 1;

		AddDatabasePanel addDatabasePanel = new AddDatabasePanel();
		add(addDatabasePanel, constraints);
		
		AvailableDatabasePanel availableDatabasePanel = new AvailableDatabasePanel();
		constraints.gridx++;
		add(availableDatabasePanel, constraints);
		setBackground(Color.WHITE);
	}
}
