package com.nbfc.ui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JFrame;

public class HomeFrame extends JFrame {
	private static final long serialVersionUID = 1L;

	public HomeFrame() {
		setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.gridx = constraints.gridy = 0;
		
		add (new HeaderPanel()) constraints);
		
		
		constraints.gridy++;
		add (new MainPanel());
		
		setTitle("RAT");
		setSize(600, 500);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
}

