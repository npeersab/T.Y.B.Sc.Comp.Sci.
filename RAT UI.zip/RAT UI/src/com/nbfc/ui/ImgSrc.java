package com.nbfc.ui;

import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;


public class ImgSrc {

	private static final String PATH = "/home/noor/workspace/eclipseSE/RAT UI/";
	public static Image getImage(String file) {
		Image image = null;

		try {
			image = ImageIO.read(new File(PATH + file));
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		return image.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
	}

	public static Image getCapgeminiLogo() {
		return getImage("capgemini.jpg");
	}
}