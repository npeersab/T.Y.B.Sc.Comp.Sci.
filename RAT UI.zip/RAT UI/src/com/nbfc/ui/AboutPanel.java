package com.nbfc.ui;

import javax.swing.JPanel;

public class AboutPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	
	public AboutPanel() {
	}
}
