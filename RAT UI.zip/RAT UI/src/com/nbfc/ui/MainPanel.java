package com.nbfc.ui;

import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class MainPanel extends JPanel{
	private static final long serialVersionUID = 1L;

	public MainPanel() {
		JTabbedPane mainTabbedPane = new JTabbedPane();
		
		AboutPanel aboutPanel = new AboutPanel();
		mainTabbedPane.add("About RAT", aboutPanel);
		
		add(mainTabbedPane);
	}
}
