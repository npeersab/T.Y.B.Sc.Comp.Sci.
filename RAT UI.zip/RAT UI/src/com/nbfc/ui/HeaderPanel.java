package com.nbfc.ui;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class HeaderPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	public HeaderPanel() {
		setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.gridx = constraints.gridy = 0;
		constraints.insets = new Insets(0, 20, 0, 10);
		
		
		add(new JLabel(new ImageIcon(ImgSrc.getCapgeminiLogo())), constraints);
		
		JLabel label = new JLabel("Report Automation Tool");
		label.setFont(new Font("Arial", Font.BOLD, 30));
		
		constraints.gridx = 1;
		add(label, constraints);
		
		constraints.gridx = 2;
		add(new JLabel(new ImageIcon(ImgSrc.getCapgeminiLogo())), constraints);
	}
}
