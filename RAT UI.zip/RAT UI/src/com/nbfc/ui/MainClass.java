package com.nbfc.ui;

import com.nbfc.ui.frame.HomeFrame;

public class MainClass {
	public static void main(String[] args) {
		new HomeFrame();
	}
}
